// Função principal para verificar o token e redirecionar ou exibir mensagem
async function validateTokenAndRedirect() {
  // Obtém o token da URL
  const urlParams = new URLSearchParams(window.location.search);
  const token = urlParams.get("token");

  if (!token) {
    displayMessage("Token não encontrado na URL.");
    return;
  }

  try {
    // Faz a requisição ao Bitrix para verificar o token
    const response = await fetch(
      "https://crm.hub-bnk.com/rest/1/6jzpwbnt07v17gi2/lists.element.get",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          IBLOCK_TYPE_ID: "bitrix_processes",
          IBLOCK_ID: "927",
          FILTER: {
            PROPERTY_5057: token,
          },
        }),
      }
    );

    const data = await response.json();

    // Verifica se o resultado está vazio
    if (data.result && data.result.length > 0) {
      // Obtém a URL do formulário do campo PROPERTY_5053
      const property5053 = data.result[0].PROPERTY_5053;
      const formUrl = property5053 ? Object.values(property5053)[0] : null;

      if (formUrl) {
        // Embute o formulário dentro da mesma página
        displayForm(formUrl);
      } else {
        displayMessage("A URL do formulário não foi encontrada.");
      }
    } else {
      displayMessage("Card concluído não aceitamos devolutivas.");
    }
  } catch (error) {
    console.error("Erro ao validar o token:", error);
    displayMessage("Ocorreu um erro ao processar sua solicitação.");
  }
}

// Função para exibir uma mensagem na tela
function displayMessage(message) {
  document.getElementById("app-container").innerHTML = `
        <div style="text-align: center; padding: 20px; font-family: Arial, sans-serif;">
            <h1>${message}</h1>
        </div>
    `;
}

// Função para exibir o formulário em um iframe
function displayForm(url) {
  document.getElementById("app-container").innerHTML = `
        <iframe src="${url}"></iframe>
    `;
}

// Executa a função ao carregar a página
window.onload = validateTokenAndRedirect;
